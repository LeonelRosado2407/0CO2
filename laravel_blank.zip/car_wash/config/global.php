<?php

return [

    /*
    |--------------------------------------------------------------------------
    | User Defined Variables
    |--------------------------------------------------------------------------
    |
    | This is a set of variables that are made specific to this application
    | that are better placed here rather than in .env file.
    | Use config('your_key') to get the values.
    |
    */

    'correoSistema' => "vlchucho8@gmail.com",
    'tiempoReserva' => 600,
    'claveCarritosAbandonados' => "\$2y\$10\$rwSH1eG1owsb4oXXdKKqLu/SyLtsuEfLxr8Sk2/WewIl/VF7Nm.uu"

];