<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Model\Libro;

class DemoController extends Controller{

	

    


 
 
}